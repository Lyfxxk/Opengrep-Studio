const API_KEY = 'sk-demo-hardcoded-123456';

module.exports = { API_KEY };
