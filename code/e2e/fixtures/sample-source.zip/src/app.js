const API_KEY = 'sk-demo-hardcoded-123456';

function run(input) {
  return eval(input);
}

module.exports = { API_KEY, run };
